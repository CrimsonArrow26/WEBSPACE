import { auth, providerGoogle, providerFacebook } from "./firebaseConfig.js";
import {
  signInWithRedirect,
  getRedirectResult,
  signInWithPopup,
} from "https://www.gstatic.com/firebasejs/11.6.0/firebase-auth.js";

document.addEventListener("DOMContentLoaded", () => {
  // Add event listener for Google Sign-In
  document.querySelector("#google-signup").addEventListener("click", () => {
    signInWithPopup(auth, providerGoogle)
      .then((result) => {
        const user = result.user;
        console.log("Google Login Success:", user);

        // Debugging redirection
        console.log("Redirecting to homepage...");
        window.location.href = "homepage.html";
      })
      .catch((err) => {
        console.error("Error during Google Sign-In:", err);
      });
  });

  // Add event listener for Facebook Sign-In
  document.querySelector("#facebook-signup").addEventListener("click", () => {
    signInWithRedirect(auth, providerFacebook);
  });

  // Handle redirect result (for Google and Facebook)
  getRedirectResult(auth)
    .then((result) => {
      if (result) {
        console.log("Redirect result received:", result);
        const user = result.user;
        console.log("User signed in successfully:", user);

        // Update UI
        document.getElementById("welcome").innerText =
          "Welcome, " + user.displayName;
        document.getElementById("profile-pic").src = user.photoURL;

        // Redirect to homepage
        window.location.href = "homepage.html";
      } else {
        console.log("No redirect result found.");
      }
    })
    .catch((error) => {
      console.error("Error during sign-in with redirect:", error);
    });

  // Optional: Auto-fill welcome message if already signed in
  onAuthStateChanged(auth, (user) => {
    if (user) {
      document.getElementById("welcome").innerText =
        "Welcome, " + user.displayName;
      document.getElementById("profile-pic").src = user.photoURL;
    }
  });
});
