import { auth, signInWithEmailAndPassword } from "./firebaseConfig.js";

document.addEventListener("DOMContentLoaded", function () {
  const signInBtn = document.getElementById("signInBtn");
  const emailInput = document.getElementById("email");
  const passwordInput = document.getElementById("password");

  signInBtn.addEventListener("click", function (e) {
    e.preventDefault();
    const email = emailInput.value;
    const password = passwordInput.value;

    signInWithEmailAndPassword(auth, email, password)
      .then((userCredential) => {
        const user = userCredential.user;
        console.log("Login Success:", user);

        window.location.href = "homepage.html";
      })
      .catch((error) => {
        console.error("Error during login:", error);
        alert("Login failed. Please check your credentials and try again.");
      });
  });
});
