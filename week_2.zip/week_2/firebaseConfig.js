export const firebaseConfig = {
    apiKey: "AIzaSyCDHjGnKQhw4Q33pHSuHCfvzABI5-Ft7Jg",
    authDomain: "nivaran-9bc6b.firebaseapp.com",
    projectId: "nivaran-9bc6b",
    storageBucket: "nivaran-9bc6b.appspot.com",
    messagingSenderId: "431802679807",
    appId: "1:431802679807:web:8fcaa4016379c8a99ae7ca",
    measurementId: "G-1PX9CJV5GV"
};