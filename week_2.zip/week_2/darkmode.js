// firebaseConfig.js
import { initializeApp } from "https://www.gstatic.com/firebasejs/11.6.0/firebase-app.js";
import { getAuth } from "https://www.gstatic.com/firebasejs/11.6.0/firebase-auth.js";
import { getFirestore } from "https://www.gstatic.com/firebasejs/11.6.0/firebase-firestore.js";

// Full Firebase config
const firebaseConfig = {
  apiKey: "AIzaSyCDHjGnKQhw4Q33pHSuHCfvzABI5-Ft7Jg",
  authDomain: "nivaran-9bc6b.firebaseapp.com",
  projectId: "nivaran-9bc6b",
  storageBucket: "nivaran-9bc6b.appspot.com",
  messagingSenderId: "431802679807",
  appId: "1:431802679807:web:8fcaa4016379c8a99ae7ca",
  measurementId: "G-1PX9CJV5GV"
};

const app = initializeApp(firebaseConfig);

// Export everything you need
const auth = getAuth(app);
const db = getFirestore(app);

export { app, auth, db };
